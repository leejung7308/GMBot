import discord
from discord.ext import commands
from discord.ui import Button, View
import random
import asyncio
import json
import os
from datetime import datetime, timedelta, timezone
import openpyxl
from io import BytesIO
import random
import re
import pytz

kst = pytz.timezone('Asia/Seoul')

# 봇 초기화
intents = discord.Intents.default()
intents.messages = True  # 메시지를 읽기 위한 권한
intents.reactions = True  # 반응을 읽기 위한 권한
intents.message_content = True  # 메시지 내용을 읽기 위한 권한
intents.members = True  # 멤버 목록을 읽기 위한 권한
intents.guilds = True  # 서버 목록을 읽기 위한 권한

bot = commands.Bot(command_prefix='!', intents=intents)

CONFIG_FILE = 'config.json'
GUILD_FILE = 'guilds.json'

def save_config(data):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            # JSONDecodeError 발생 시 기본값으로 초기화
            return {}
    return {}

def save_guilds(data):
    with open(GUILD_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def load_guilds():
    if os.path.exists(GUILD_FILE):
        try:
            with open(GUILD_FILE, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print("길드 파일이 손상되었습니다.")
            return {}
    return {}

@bot.event
async def on_ready():
    await bot.change_presence(activity=discord.Game(name="인사"))
    print(f'Logged in as {bot.user}')

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    if message.content.startswith('!'):
        await bot.process_commands(message)

    if message.content.startswith('!') and not message.content.startswith('!청소'):
        await message.delete()

@bot.event
async def on_member_join(member):
    role = discord.utils.get(member.guild.roles, name="새싹")
    if role:
        try:
            await member.add_roles(role)
        except discord.Forbidden:
            print(f"권한부족: {member}에게 역할을 부여할 수 없습니다.")
        except discord.HTTPException as e:
            print(f"오류 발생: {e}")

@bot.event
async def on_raw_reaction_add(payload):

    guild_id = str(payload.guild_id)

    ## 역할 부여
    config = load_config()
    if guild_id in config:
        announcement_message_id = config[guild_id].get('announcement_message_id')
        if announcement_message_id:
            if payload.message_id == announcement_message_id:
                guild = bot.get_guild(payload.guild_id)
                if guild:
                    role = None
                    if str(payload.emoji) == '📝':
                        role = discord.utils.get(guild.roles, name="기획")
                    if str(payload.emoji) == '💻':
                        role = discord.utils.get(guild.roles, name="프로그래밍")
                    if str(payload.emoji) == '🎨':
                        role = discord.utils.get(guild.roles, name="아트")
                    if str(payload.emoji) == '🎵':
                        role = discord.utils.get(guild.roles, name="사운드")
                    if str(payload.emoji) == '✅':
                        role = discord.utils.get(guild.roles, name="GM 일반멤버")
        
                    if role is not None:
                        member = guild.get_member(payload.user_id)
                        if member is not None:
                            try:
                                await member.add_roles(role)
                                await member.remove_roles(discord.utils.get(guild.roles, name="새싹"))
                                if guild_id in config and 'welcome_channel_id' in config[guild_id]:
                                    welcome_channel_id = config[guild_id]['welcome_channel_id']
                                    welcome_channel = bot.get_channel(welcome_channel_id)
                                if welcome_channel:
                                    # 공지 채널에 환영 메시지 전송
                                    embed = discord.Embed(
                                        title="🖐️GameMakers에 오신 것을 환영합니다!🖐️",
                                        description=f"모두 {member.mention}님을 환영해주세요!",
                                        color=discord.Color.blue()
                                    )
                                    await welcome_channel.send(embed=embed)
                            except discord.Forbidden:
                                print(f"권한부족: {member}에게 역할을 부여할 수 없습니다.")
                            except discord.HTTPException as e:
                                print(f"오류 발생: {e}")

    ## 길드 가입
    guilds = load_guilds()
    if guild_id in guilds: #얘는 길드
        for guild_name, guild_info in guilds[guild_id].items():
            if isinstance(guild_info, dict):
                if payload.message_id == guild_info['message_id']:
                    guild = bot.get_guild(payload.guild_id)
                    if guild: #얘는 서버
                        member = guild.get_member(payload.user_id)
                        if member:
                            if str(payload.emoji) == '📝':
                                guild_role = guild.get_role(guild_info['role_id'])
                                if guild_role:
                                    if 'guild_members' not in guild_info:
                                        guild_info['guild_members'] = []
                                    channel = bot.get_channel(payload.channel_id)
                                    message = await channel.fetch_message(payload.message_id)
                                    if member.id in guild_info['guild_members']:
                                        await member.send("이미 가입된 길드입니다.")
                                        await message.remove_reaction(payload.emoji, member)
                                        return
                                    elif member.id == guild_info['guild_leader_id']:
                                        await member.send("해당 길드의 길드 마스터입니다.")
                                        await message.remove_reaction(payload.emoji, member)
                                        return
                                    else:
                                        await message.remove_reaction(payload.emoji, member)
                                        embed = discord.Embed(
                                            description=f"{member.mention}님, {guild_info['guild_name']} 길드 가입 대기 상태입니다.",
                                            color=discord.Color.yellow()
                                        )
                                        wait_msg = await member.send(embed=embed)
                                        guild_master = guild.get_member(guild_info['guild_leader_id'])
                                        embed = discord.Embed(
                                            title=f"{guild_role.name} 길드 가입 신청",
                                            description=f"{member.mention}님께서 {guild_info['guild_name']} 길드 가입을 신청하셨습니다.",
                                            color=discord.Color.yellow()
                                        )
                                        apply_msg = await guild_master.send(embed=embed)
                                        await apply_msg.add_reaction('⭕')
                                        await apply_msg.add_reaction('❌')
                                        
                                        bot.loop.create_task(wait_for_guild_master_decision(apply_msg, message, wait_msg, member, guild_info, guild))
                                        
                                        break
                
    
async def wait_for_guild_master_decision(apply_msg, guild_message, wait_msg, member, guild_info, guild):
    def check(reaction, user):
        return user != bot.user and str(reaction.emoji) in ['⭕', '❌'] and reaction.message.id == apply_msg.id
    guild_role = guild.get_role(guild_info['role_id'])
    reaction, user = await bot.wait_for('reaction_add', check=check)
    if str(reaction.emoji) == '⭕':
        await member.add_roles(guild_role)
        embed = discord.Embed(description=f"{member.mention}님의 {guild_info['guild_name']} 길드 가입 신청이 승인되었습니다.", color=discord.Color.green())
        await apply_msg.edit(embed=embed)
        embed = discord.Embed(description=f"{member.mention}님, {guild_info['guild_name']} 길드 가입 신청이 승인되었습니다.", color=discord.Color.green())
        await wait_msg.edit(embed=embed)
        guild_info['guild_members'].append(member.id)
        await update_guild_message(guild_message, guild_info)
        await save_guild_info(guild_info, guild)
    elif str(reaction.emoji) == '❌':
        embed = discord.Embed(description=f"{member.mention}님의 {guild_info['guild_name']} 길드 가입 신청이 거절되었습니다.", color=discord.Color.red())
        await apply_msg.edit(embed=embed)
        embed = discord.Embed(description=f"{member.mention}님, {guild_info['guild_name']} 길드 가입 신청이 거절되었습니다.", color=discord.Color.red())
        await wait_msg.edit(embed=embed)
        

async def save_guild_info(guild_info, guild):
    guilds = load_guilds()
    guild_id = str(guild.id)
    guild_name = guild_info['guild_name']
    guilds[guild_id][guild_name] = guild_info
    save_guilds(guilds)

@bot.command(name='추첨', help='(운영진 전용)특정 메시지에 특정 이모지를 남긴 사람들 중 당첨자를 추첨합니다.\n사용법 : !추첨 <메시지 ID> <이모지> <당첨 인원>')
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 추첨(ctx, message_id: int, emoji: str, number_of_winners: int):
    try:
        # 메시지 가져오기
        message = await ctx.channel.fetch_message(message_id)
        # 해당 이모지를 반응으로 남긴 사용자 목록 가져오기
        reaction = discord.utils.get(message.reactions, emoji=emoji)
        if reaction is None:
            await ctx.send(f"해당 메시지에 {emoji} 이모지가 없습니다.")
            return

        users = []
        async for user in reaction.users():
            if user != bot.user:
                users.append(user)

        # 추첨 인원이 전체 인원보다 많으면 오류 메시지 출력
        if number_of_winners > len(users):
            await ctx.send("추첨 인원이 반응한 인원보다 많습니다.")
            return

        # 추첨
        winners = random.sample(users, number_of_winners)

        # 당첨자 목록 출력
        winners_list = '\n'.join([winner.mention for winner in winners])
        message = await ctx.send("3초 후에 당첨자를 발표합니다.")
    
        for i in range(3, 0, -1):
            await asyncio.sleep(1)
            await message.delete()
            message = await ctx.send(f"{i}...")
        await asyncio.sleep(1)
        await message.delete()
        await ctx.send(
f"""
\U0001F973 축하드립니다! \U0001F973 
-----------------------------------
당첨 인원: {number_of_winners}명
당첨자: 
{winners_list}
-----------------------------------
"""
)

    except Exception as e:
        await ctx.send(f"오류 발생: {str(e)}")

@bot.command(name='청소', help='(운영진 전용)개수만큼 메시지를 삭제합니다.\n사용법 : !청소 <개수>')
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 청소(ctx, number: int):
    await ctx.channel.purge(limit=number + 1)

@bot.command(name='공지등록', help='(운영진 전용)반응으로 역할 자동 부여되는 공지사항 메시지 ID를 등록합니다.\n사용법 : !공지등록 <메시지 ID>')
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 공지등록(ctx, message_id: int):
    config = load_config()
    guild_id = str(ctx.guild.id)
    if guild_id not in config:
        config[guild_id] = {}
    if 'announcement_message_id' in config[guild_id]:
        if message_id == config[guild_id]['announcement_message_id']:
            await ctx.send("이미 해당 메시지 ID가 등록되어 있습니다.")
            return
        else:
            await ctx.send("기존 메시지 ID를 삭제하고 새로운 메시지 ID를 등록합니다.")
            config[guild_id].pop('announcement_message_id')

    config[guild_id]['announcement_message_id'] = message_id
    save_config(config)
    print(f"공지사항 메시지 ID가 {message_id}로 설정되었습니다.")

@bot.command(name='환영채널등록', help='(운영진 전용)환영인사 메시지가 올라오는 환영인사 채널 ID를 등록합니다.\n사용법 : !환영채널등록 <채널 ID>')
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 환영채널등록(ctx, channel: discord.TextChannel):
    config = load_config()
    guild_id = str(ctx.guild.id)
    if guild_id not in config:
        config[guild_id] = {}
    if 'welcome_channel_id' in config[guild_id]:
        if channel.id == config[guild_id]['welcome_channel_id']:
            await ctx.send("이미 해당 채널이 등록되어 있습니다.")
            return
        else:
            await ctx.send("기존 채널을 삭제하고 새로운 채널을 등록합니다.")
            config[guild_id].pop('welcome_channel_id')
            
    config[guild_id]['welcome_channel_id'] = channel.id
    save_config(config)
    print(f"환영 채널이 {channel.mention} 으로 설정되었습니다.")

@bot.command(name='도움말', help='사용 가능한 명령어 목록을 출력합니다.\n사용법 : !도움말')
async def 도움말(ctx):
    embed = discord.Embed(
        title="GM봇 도움말",
        description="GM봇은 다양한 기능을 제공합니다.",
        color=discord.Color.blue()
    )
    user_roles = [role.name for role in ctx.author.roles]

    # 명령어를 이름 기준으로 정렬
    sorted_commands = sorted(bot.commands, key=lambda x: x.name)
    higher_commands = []
    for command in sorted_commands:
        if command.name == 'help':
            continue
        
        if command.help.startswith('(운영진 전용)'):
            if not any(role in user_roles for role in ['봇 관리자', '운영부', 'GM 관리자']):
                continue
            else:
                higher_commands.append(command)
                continue


        embed.add_field(name=f"**{bot.command_prefix}{command.name}**", value=f"```{command.help}```", inline=False)
    if any(role in user_roles for role in ['봇 관리자', '운영부', 'GM 관리자']):
        embed.add_field(name="#__운영진 전용 명령어__#",value="⬇️⬇️⬇️아래부터는 운영진 전용 명령어입니다.⬇️⬇️⬇️" , inline=False)
        for command in higher_commands:
            embed.add_field(name=f"**{bot.command_prefix}{command.name}**", value=f"```{command.help}```", inline=False)
    await ctx.author.send(embed=embed)

@bot.command(name='길드도움말', help='길드 관련 명령어 목록을 출력합니다.\n사용법 : !길드도움말')
async def 길드도움말(ctx):
    embed = discord.Embed(
        title="GM봇 길드 도움말",
        description="길드 관련 명령어 목록입니다.",
        color=discord.Color.blue()
    )
    user_roles = [role.name for role in ctx.author.roles]
    higher_commands = []

    # 명령어를 이름 기준으로 정렬
    sorted_commands = sorted(bot.commands, key=lambda x: x.name)
    
    for command in sorted_commands:
        if not command.name.startswith('길드'):
            continue
        
        if command.name == 'help':
            continue
        
        if command.help.startswith('(운영진 전용)'):
            if not any(role in user_roles for role in ['봇 관리자', '운영부', 'GM 관리자']):
                continue
            else:
                higher_commands.append(command)
                continue

        embed.add_field(name=f"**{bot.command_prefix}{command.name}**", value=f"```{command.help}```", inline=False)
    if any(role in user_roles for role in ['봇 관리자', '운영부', 'GM 관리자']):
        embed.add_field(name="#__운영진 전용 명령어__#",value="⬇️⬇️⬇️아래부터는 운영진 전용 명령어입니다.⬇️⬇️⬇️" , inline=False)
        for command in higher_commands:
            embed.add_field(name=f"**{bot.command_prefix}{command.name}**", value=f"```{command.help}```", inline=False)
    await ctx.author.send(embed=embed)

@bot.command(name='길드카테고리등록', help='(운영진 전용)길드 카테고리를 등록합니다.\n사용법 : !길드카테고리등록 <카테고리 ID>')
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 길드카테고리등록(ctx, category: discord.CategoryChannel):
    guilds = load_guilds()
    guild_id = str(ctx.guild.id)
    if guild_id not in guilds:
        guilds[guild_id] = {}
    if 'category_id' in guilds[guild_id]:
        if category.id == guilds[guild_id]['category_id']:
            await ctx.send("이미 해당 카테고리가 등록되어 있습니다.")
            return
        else:
            await ctx.send("기존 카테고리를 삭제하고 새로운 카테고리를 등록합니다.")
            guilds[guild_id].pop('category_id')

    guilds[guild_id]['category_id'] = category.id
    save_guilds(guilds)
    await ctx.send(f"길드 카테고리가 {category.name}으로 설정되었습니다.")

@bot.command(name='길드목록채널등록', help='(운영진 전용)길드 목록 채널을 등록합니다.\n사용법 : !길드목록채널등록 <채널 ID>')
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 길드목록채널등록(ctx, channel: discord.TextChannel):
    guilds = load_guilds()
    guild_id = str(ctx.guild.id)
    if guild_id not in guilds:
        guilds[guild_id] = {}
    if 'list_channel_id' in guilds[guild_id]:
        if channel.id == guilds[guild_id]['list_channel_id']:
            await ctx.send("이미 해당 채널이 등록되어 있습니다.")
            return
        else:
            await ctx.send("기존 채널을 삭제하고 새로운 채널을 등록합니다.")
            guilds[guild_id].pop('list_channel_id')
    
    guilds[guild_id]['list_channel_id'] = channel.id
    save_guilds(guilds)
    await ctx.send(f"길드 목록 채널이 {channel.name}으로 설정되었습니다.")

@bot.command(name='길드생성', help='길드를 생성합니다.\n길드명은 띄어쓰기가 불가능합니다.\n길드 설명은 띄어쓰기 및 줄바꿈(쉬프트+엔터)이 가능합니다.\n사용법 : !길드생성 <길드명> <길드 설명>')
async def 길드생성(ctx, name: str, *, description: str):
    guilds = load_guilds()
    guild_id = str(ctx.guild.id)
    created_role = None
    created_channel = None
    created_message = None

    try:
        if guild_id not in guilds:
            guilds[guild_id] = {}

        category_id = guilds[guild_id].get('category_id')
        if category_id is None:
            message = await ctx.send("길드 카테고리가 설정되지 않았습니다.")
            await asyncio.sleep(2)
            await message.delete()
            return

        category = ctx.guild.get_channel(category_id)
        if category is None:
            message = await ctx.send("길드 카테고리를 찾을 수 없습니다.")
            await asyncio.sleep(2)
            await message.delete()
            return

        author_avatar_url = ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url

        embed = discord.Embed(
            title=f"{name} 길드",
            color=discord.Color.blue()
        )
        embed.set_author(name=ctx.author.display_name, icon_url=author_avatar_url)
        embed.add_field(name="길드 설명", value=f">>> {description}", inline=False)
        embed.add_field(name="길드 마스터", value=ctx.author.mention, inline=False)
        embed.add_field(name="길드원", value="", inline=False)
        embed.add_field(name="길드 가입", value="📝 이모지를 누르면 길드 마스터에게 길드 가입 신청 메시지가 전송됩니다. 이후, 길드 마스터의 승인 하에 길드에 가입하실 수 있습니다.", inline=False)
        embed.set_thumbnail(url=author_avatar_url)

        guild_role = await ctx.guild.create_role(name=f"{name}(길드)")

        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            guild_role: discord.PermissionOverwrite(read_messages=True)
        }

        list_channel = bot.get_channel(guilds[guild_id].get('list_channel_id'))

        guild = await ctx.guild.create_text_channel(name, category=category, overwrites=overwrites)

        await ctx.author.add_roles(guild_role)
        created_message = await list_channel.send(embed=embed)
        await ctx.send(f"{name} 길드가 생성되었습니다.")

        guilds[guild_id][name] = {
            'guild_name': name,
            'guild_leader_id': ctx.author.id,
            'role_id': guild_role.id,
            'channel_id': guild.id,
            'message_id': created_message.id
        }
        await created_message.add_reaction('📝')
        save_guilds(guilds)

    except Exception as e:
        if created_role:
            await created_role.delete()
        if created_channel:
            await created_channel.delete()
        if created_message:
            await created_message.delete()
        await ctx.author.send(f"오류 발생: {str(e)}. 길드 생성에 실패했습니다.")

@bot.command(name='길드삭제', help='(운영진 전용)길드를 삭제합니다.\n사용법 : !길드삭제 <길드명>')
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 길드삭제(ctx, name: str):
    guilds = load_guilds()
    guild_id = str(ctx.guild.id)
    if guild_id not in guilds or name not in guilds[guild_id]:
        await ctx.author.send("해당 길드를 찾을 수 없습니다.")
        return

    guild_info = guilds[guild_id][name]
    guild = ctx.guild.get_channel(guild_info['channel_id'])
    if guild is not None:
        await guild.delete()

    role = ctx.guild.get_role(guild_info['role_id'])
    if role is not None:
        await role.delete()

    list_channel = ctx.guild.get_channel(guilds[guild_id].get('list_channel_id'))
    message = await list_channel.fetch_message(guild_info['message_id'])
    await message.delete()

    del guilds[guild_id][name]
    save_guilds(guilds)
    await ctx.author.send(f"{name} 길드가 삭제되었습니다.")

@bot.command(name='길드탈퇴', help='길드를 탈퇴합니다.\n사용법 : !길드탈퇴 <길드명>')
async def 길드탈퇴(ctx, name: str):
    guilds = load_guilds()
    guild_id = str(ctx.guild.id)
    if guild_id not in guilds or name not in guilds[guild_id]:
        await ctx.author.send("해당 길드를 찾을 수 없습니다.")
        return

    guild_info = guilds[guild_id][name]

    if ctx.author.id == guild_info['guild_leader_id']:
        await ctx.author.send("해당 길드의 길드 마스터는 탈퇴할 수 없습니다.")
        return
    
    guild_role = ctx.guild.get_role(guild_info['role_id'])
    if guild_role is not None:
        await ctx.author.remove_roles(guild_role)

    list_channel = ctx.guild.get_channel(guilds[guild_id].get('list_channel_id'))
    message = await list_channel.fetch_message(guild_info['message_id'])
    if ctx.author.id in guild_info['guild_members']:
        guild_info['guild_members'].remove(ctx.author.id)
        await update_guild_message(message, guild_info)
        save_guilds(guilds)
    await ctx.author.send(f"{name} 길드에서 탈퇴되었습니다.")

@bot.command(name='길드멤버퇴출', help='길드 멤버를 퇴출합니다.(길드 마스터 전용)\n사용법 : !길드멤버퇴출 <길드명> <사용자ID>')
async def 길드멤버퇴출(ctx, name: str, member_id: int):
    guilds = load_guilds()
    guild_id = str(ctx.guild.id)
    
    if guild_id not in guilds or name not in guilds[guild_id]:
        await ctx.author.send("해당 길드를 찾을 수 없습니다.")
        return

    guild_info = guilds[guild_id][name]

    if ctx.author.id != guild_info['guild_leader_id']:
        await ctx.author.send("해당 길드의 길드 마스터만 길드원을 퇴출할 수 있습니다.")
        return
    
    member = ctx.guild.get_member(member_id)
    if member is None:
        await ctx.author.send("사용자를 찾을 수 없습니다.")
        return
    
    guild_role = ctx.guild.get_role(guild_info['role_id'])
    if guild_role is None:
        await ctx.author.send("길드 역할을 찾을 수 없습니다.")
        return

    if member.id == guild_info['guild_leader_id']:
        await ctx.author.send("길드 마스터는 퇴출할 수 없습니다.")
        return

    list_channel = ctx.guild.get_channel(guilds[guild_id].get('list_channel_id'))
    message = await list_channel.fetch_message(guild_info['message_id'])

    if member.id in guild_info['guild_members']:
        guild_info['guild_members'].remove(member.id)
        await update_guild_message(message, guild_info)
        save_guilds(guilds)
        await member.remove_roles(guild_role)
        await member.send(f"{name} 길드에서 퇴출되었습니다.")
    else:
        await ctx.send("해당 사용자는 길드에 가입되어 있지 않습니다.")

@bot.command(name='길드명변경', help='길드명을 변경합니다.(길드 마스터 전용)\n사용법 : !길드명변경 <기존 길드명> <새 길드명>')
async def 길드명변경(ctx, old_name: str, new_name: str):
    guilds = load_guilds()
    guild_id = str(ctx.guild.id)
    if guild_id not in guilds or old_name not in guilds[guild_id]:
        await ctx.author.send("해당 길드를 찾을 수 없습니다.")
        return

    guild_info = guilds[guild_id][old_name]
    if ctx.author.id != guild_info['guild_leader_id']:
        await ctx.author.send("해당 길드의 길드 마스터만 길드명을 변경할 수 있습니다.")
        return
    
    guild_role = ctx.guild.get_role(guild_info['role_id'])
    if guild_role is not None:
        await guild_role.edit(name=f"{new_name}(길드)")

    list_channel = ctx.guild.get_channel(guilds[guild_id].get('list_channel_id'))
    message = await list_channel.fetch_message(guild_info['message_id'])
    embed = message.embeds[0]
    embed.title = f"{new_name} 길드"
    await message.edit(embed=embed)

    guilds[guild_id][new_name] = guilds[guild_id].pop(old_name)
    save_guilds(guilds)
    await ctx.author.send(f"{old_name} 길드명이 {new_name}으로 변경되었습니다.")

async def update_guild_message(message, guild_info):
    member_mentions = []
    for member_id in guild_info['guild_members']:
        member = message.guild.get_member(member_id)
        if member:
            member_mentions.append(member.mention)
    updated_members = ', '.join(member_mentions)
    embed = message.embeds[0]
    embed.set_field_at(2, name="길드원", value=updated_members, inline=False)
    await message.edit(embed=embed)

@bot.command(name="출석채널등록", help="(운영진 전용)회원 출석 채널을 등록합니다.\n사용법 : !출석채널등록 <채널 ID>")
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 출석채널등록(ctx, channel: discord.TextChannel):
    config = load_config()
    guild_id = str(ctx.guild.id)
    if guild_id not in config:
        config[guild_id] = {}
    if 'attendance_channel_id' in config[guild_id]:
        if channel.id == config[guild_id]['attendance_channel_id']:
            await ctx.send("이미 해당 채널이 등록되어 있습니다.")
            return
        else:
            await ctx.send("기존 채널을 삭제하고 새로운 채널을 등록합니다.")
            config[guild_id].pop('attendance_channel_id')
    
    config[guild_id]['attendance_channel_id'] = channel.id
    save_config(config)
    await ctx.send(f"출석 채널이 {channel.name}으로 설정되었습니다.")

@bot.command(name="출석시작", help="(운영진 전용)출석부를 만듭니다.\n사용법 : !출석시작")
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 출석시작(ctx):
    global member_codes

    today_date = datetime.now(kst).strftime("%y.%m.%d")

    file_name = f"{today_date}_{ctx.guild.name}_출석부.xlsx"
    if os.path.exists(file_name):
        await ctx.send("이미 출석이 진행중입니다.")
        return
    members = ctx.guild.members
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "출석부"
    sheet.append(["이름", "출결", "출석 코드"])
    member_codes = {}
    datas = []
    for member in members:
        if not member.bot:
            match = re.search(r'\[.*?\]\s*(.*)', member.display_name)
            if match:
                clean_name = match.group(1).replace(" ", "")
            else:
                clean_name = member.display_name.replace(" ", "")
            
            code = random.randint(1000, 9999)
            member_codes[member.id] = code
            datas.append([clean_name, "결석", code])
    datas.sort(key=lambda x: x[0])
    for data in datas:
        sheet.append(data)

    workbook.save(file_name)

    datas.clear()

    buttons = []
    for member in members:
        if not member.bot:
            match = re.search(r'\[.*?\]\s*(.*)', member.display_name)
            if match:
                clean_name = match.group(1).replace(" ", "")
            else:
                clean_name = member.display_name.replace(" ", "")
            datas.append([clean_name,f"check_{member.id}"])
    
    datas.sort(key=lambda x: x[0])
    for data in datas:
        button = discord.ui.Button(style=discord.ButtonStyle.primary, label=data[0], custom_id=data[1])
        buttons.append(button)

    view = discord.ui.View()
    for button in buttons:
        view.add_item(button)
    
    configs = load_config()
    guild_id = str(ctx.guild.id)

    if guild_id in configs:
        if 'attendance_message_id' in configs[guild_id]:
            message_id = configs[guild_id]['attendance_message_id']
            try: 
                message = await ctx.channel.fetch_message(message_id)
                await message.delete()
            except Exception as e:
                print(f"메시지를 찾을 수 없습니다. {str(e)}")
    view_message = await ctx.send("출석 코드를 확인하려면 아래 버튼을 눌러주세요.", view=view)

    if guild_id in configs:
        configs[guild_id]['attendance_message_id'] = view_message.id
        save_config(configs)

    embed = discord.Embed(
        title=f"{today_date} 출석 현황",
        description="출석 진행중",
        color=discord.Color.green()
    )
    embed.add_field(name="출석", value="", inline=False)
    if guild_id in configs:
        if 'attendance_channel_id' in configs[guild_id]:
            attendance_channel_id = configs[guild_id]['attendance_channel_id']
            attendance_channel = bot.get_channel(attendance_channel_id)
            if attendance_channel:
                message = await attendance_channel.send(embed=embed)
                sheet.cell(row=1, column=4, value=str(message.id))
                workbook.save(file_name)

@bot.command(name="출석", help="출석 체크를 합니다.\n사용법 : !출석 <출석 코드>")
async def 출석(ctx, code: str):
    today_date = datetime.now(kst).strftime("%y.%m.%d")
    file_name = f"{today_date}_{ctx.guild.name}_출석부.xlsx"
    try:
        workbook = openpyxl.load_workbook(file_name)
        sheet = workbook.active

        match = re.search(r'\[.*?\]\s*(.*)', ctx.author.display_name)
        if match:
            member_name = match.group(1).replace(" ", "")
        else:
            member_name = ctx.author.display_name.replace(" ", "")

        name_col = 1
        code_col = 3
        attendance_col = 2

        configs = load_config()
        guild_id = str(ctx.guild.id)
        message = None
        if guild_id in configs:
            if 'attendance_channel_id' in configs[guild_id]:
                attendance_channel_id = configs[guild_id]['attendance_channel_id']
                attendance_channel = bot.get_channel(attendance_channel_id)
                if attendance_channel:
                    message_id = sheet.cell(row=1, column=4).value
                    message = await attendance_channel.fetch_message(message_id)

        name_found = False
        for idx, row in enumerate(sheet.iter_rows(min_row=2, values_only=False),start=2):
            if row[name_col-1].value == member_name:
                name_found = True
                if  str(row[code_col-1].value) == code.strip():
                    sheet.cell(row = idx, column = attendance_col, value = "O")
                    workbook.save(file_name)
                    embed = discord.Embed(
                        title=f"{today_date}",
                        description="출석 완료",
                        color=discord.Color.green()
                    )
                    await ctx.author.send(embed=embed)
                    if message:
                        await update_attendance_message(message, ctx.author)
                else:
                    embed = discord.Embed(
                        title=f"오류",
                        description="출석 코드가 일치하지 않습니다.",
                        color=discord.Color.red()
                    )
                    await ctx.author.send(embed=embed)
                break
        if not name_found:
            embed = discord.Embed(
                title=f"오류",
                description="이름을 찾을 수 없습니다.",
                color=discord.Color.red()
            )
            await ctx.author.send(embed=embed)
    except FileNotFoundError:
        await ctx.author.send("출석부 파일을 찾을 수 없습니다.")
    except Exception as e:
        await ctx.author.send(f"오류 발생: {str(e)}")

@bot.command(name="출석종료", help="(운영진 전용)출석부를 종료하고 엑셀 파일을 저장합니다.\n사용법 : !출석종료")
@commands.has_any_role('봇 관리자', '운영부', 'GM 관리자')
async def 출석종료(ctx):
    today_date = datetime.now(kst).strftime("%y.%m.%d")
    file_name = f"{today_date}_{ctx.guild.name}_출석부.xlsx"
    workbook = openpyxl.load_workbook(file_name)
    sheet = workbook.active
    configs = load_config()
    guild_id = str(ctx.guild.id)
    message = None
    if guild_id in configs:
        if 'attendance_channel_id' in configs[guild_id]:
            attendance_channel_id = configs[guild_id]['attendance_channel_id']
            attendance_channel = bot.get_channel(attendance_channel_id)
            if attendance_channel:
                message_id = sheet.cell(row=1, column=4).value
                message = await attendance_channel.fetch_message(message_id)
        
    try:
        if message:
            embed = message.embeds[0]
            embed.description = "출석 종료"
            embed.color = discord.Color.red()
            await message.edit(embed=embed)
        await ctx.send(file=discord.File(file_name))
        os.remove(file_name)
    except FileNotFoundError:
        await ctx.send("출석부 파일을 찾을 수 없습니다.")
    except Exception as e:
        await ctx.send(f"오류 발생: {str(e)}")

@bot.event
async def on_interaction(interaction: discord.Interaction):
    if interaction.type == discord.InteractionType.component:
        if interaction.custom_id.startswith('check_'):
            member_id = int(interaction.custom_id.split('_')[1])
            member = interaction.guild.get_member(member_id)
            await interaction.response.defer()
            if member:
                code = [code for m_id, code in member_codes.items() if m_id == member_id]
                if code:
                    embed = discord.Embed(
                        title="출석 코드",
                        description=f"{member.mention}님의 출석 코드는 {code[0]}입니다.",
                        color=discord.Color.blue()
                    )
                    await member.send(embed=embed)
                else:
                    await interaction.followup.send("해당 사용자의 코드를 찾을 수 없습니다.", ephemeral=True)
    
async def update_attendance_message(message, member):
    embed = message.embeds[0]
    attendance_field = embed.fields[0]
    attendance_field.value += f"{member.mention}\n"
    embed.set_field_at(0, name="출석", value=attendance_field.value, inline=False)
    await message.edit(embed=embed)

# 봇 실행
bot.run()